package com.cyanspring.custom.strategy;

import com.cyanspring.common.business.ParentOrder;
import com.cyanspring.common.marketdata.Quote;
import com.cyanspring.common.staticdata.RefData;
import com.cyanspring.common.util.FormatUtils;
import com.cyanspring.strategy.singleorder.AbstractQuantityAnalyzer;
import com.cyanspring.strategy.singleorder.QuantityInstruction;
import com.cyanspring.strategy.singleorder.SingleOrderStrategy;

public class VWAPQuantityAnalyzer extends AbstractQuantityAnalyzer {
	@Override
	protected void finalizeQty(QuantityInstruction qtyi, SingleOrderStrategy strategy) {
		if(null == qtyi)
			return;
		
		AlgoQtyInstruction qi = (AlgoQtyInstruction)qtyi;
		
		RefData refData = strategy.getRefData();
		double remainingQty = strategy.getParentOrder().getRemainingQty();
		
		if (qi.getAuctionQty() > 0) {
			qi.setAuctionQty(Math.min(refData.roundToLots(qi.getAuctionQty()), remainingQty));
			return;
		}
		
		// round to remove negative qty if any from previous calculation
		qi.setAggresiveQty(refData.roundToLots(qi.getAggresiveQty()));
		qi.setPassiveQty(refData.roundToLots(qi.getPassiveQty()));

		if(qi.getAggresiveQty() > remainingQty) {
			qi.setAggresiveQty(remainingQty);
			qi.setPassiveQty(0);
			strategy.logDebug("Capping aggressive quantity to: " + qi.getAggresiveQty());
		} else if (qi.getAggresiveQty() + qi.getPassiveQty() > remainingQty) {
			qi.setPassiveQty(remainingQty - qi.getAggresiveQty());
			strategy.logDebug("Capping passive quantity to: " + qi.getPassiveQty());
		}
		
		// round again incase any odd lots left from calculation
		double aggressiveQty = qi.getAggresiveQty();
		qi.setAggresiveQty(refData.roundToLots(qi.getAggresiveQty()));
		strategy.logDebug("Round aggressive qty from " + aggressiveQty + " to " + qi.getAggresiveQty());
		
		double passiveQty = qi.getPassiveQty();
		qi.setPassiveQty(refData.roundToLots(qi.getPassiveQty()));
		strategy.logDebug("Round passive qty from " + passiveQty + " to " + qi.getPassiveQty());
	}
	
	@Override
	protected QuantityInstruction calculate(SingleOrderStrategy strategy) {
		AlgoQtyInstruction qi = new AlgoQtyInstruction();
		VWAP vwap = (VWAP)strategy;
		ParentOrder order = strategy.getParentOrder();
		int lotSize = strategy.getRefData().getLotSize();

		double remainingQty = order.getRemainingQty();
		double cumQty = order.getCumQty();
		double orderQty = order.getQuantity();
		double targetQty = vwap.getTargetQty();
		double qtyToTarget = vwap.getQtyToTarget();
		double maxAoB = vwap.getMaxAoB();
		double extantQty = strategy.getQtyInMarket();
		double maxAoBQty = orderQty*maxAoB;
		double completeRate = cumQty / orderQty;

		strategy.logInfo("===> extQty, cumQty, remainingQty, profile%, tgt%, complete%, AoB%, tgtQty, qtyToTgt, RunningPoV% : " 
				+ FormatUtils.zeroDP(extantQty) + ", " + FormatUtils.zeroDP(cumQty) + ", " + FormatUtils.zeroDP(remainingQty) + ", "
				+ FormatUtils.twoDP(vwap.getProfileRate()*100) + "%, " + FormatUtils.twoDP(vwap.getTargetRate()*100) + "%, " 
				+ FormatUtils.twoDP(completeRate*100) + "%, " + FormatUtils.twoDP(vwap.getCurrentAoB()*100) + "%, " 
				+ FormatUtils.zeroDP(targetQty) + ", " + FormatUtils.zeroDP(qtyToTarget) + ", " + FormatUtils.twoDP(vwap.getRunningPov()) + "%");
		
		double buySellRatio = vwap.getBuySellRatio();
		double vwapPi = vwap.getVWAPpi();
		double passQty=0, aggQty=0;
		Quote quote = strategy.getQuote();

		strategy.logInfo("===> bid@vol, ask@vol, bid1@vol, ask1@vol, bid2@vol, ask2@vol, b/sRatio, rawBsRatio, depthBsRatio, vwapPxImprove, avgPx, orderVWAP, Perf: " 
				+ quote.getBid() + "@" + quote.getBidVol() + ", " + quote.getAsk() + "@" + quote.getAskVol() + ", " 
				+ quote.getBid1() + "@" + quote.getBid1Vol() + ", " + quote.getAsk1() + "@" + quote.getAsk1Vol() + ", "
				+ quote.getBid2() + "@" + quote.getBid2Vol() + ", " + quote.getAsk2() + "@" + quote.getAsk2Vol() + ", "
				+ FormatUtils.fourDP(buySellRatio) + ", " + FormatUtils.fourDP(vwap.getRawBuySellRatio()) + ", " + FormatUtils.fourDP(vwap.getDepthBuySellRatio()) + ", " 
				+ FormatUtils.fourDP(vwapPi) + ", " + FormatUtils.fourDP(order.getAvgPx()) + ", " 
				+ FormatUtils.fourDP(vwap.getOrderVWAP()) + ", " + FormatUtils.fourDP(vwap.getVWAPPerf(order.getSide())));
		
		// Perform Open Auction Logic
		if (strategy.getMarketRule().isInOpenAuctionNow(strategy)) {
			double qty = Math.max(lotSize, vwap.getQtyToTarget());
			qi.setAuctionQty(qty);
			
			strategy.logInfo("===> iep@iev, qty: " + quote.getIep() + "@" + quote.getIev() + ", " + qty);
			
			return qi;
		}
		
		// Perform FinishUp Logic
		if (vwap.isFinishUp()) {
			qi.setFinishUpQty(vwap.getFinishUpQty());
		
			return qi;
		}
		
		// Perform CleanUp Logic
		if (vwap.isCleanUpNow()) {
			double cleanUpQty = Math.min(vwap.getCleanUpQty(), remainingQty); 
			qi.setCleanUpQty(cleanUpQty);
			
			strategy.logInfo("===> Perform CleanUp with Qty: " + FormatUtils.zeroDP(cleanUpQty));
			
			if (vwap.getCleanUpVol() > 0) {
				strategy.logInfo("===> Running cleanUp Pov%: " + FormatUtils.twoDP(vwap.getRunningCleanUpPov()) + "%");
			}
		
			return qi;
		} 

		// Perform AheadOrBehind logic
		//TODO: if it's currently ahead more than AoB, it could because of cleaning up, hence need to refresh profile target
		
		/* Calculate the passive quantity 
			1. when not ahead (-qtyToTarget) more than maxAoB qty,
		*/ 
		if (-qtyToTarget < maxAoBQty) {
			passQty = Math.max(lotSize, Math.min(orderQty*vwap.getMinPassiveOrderSize()+qtyToTarget, orderQty*maxAoB));
			
		} else {
			// maintain the same extantQty if it's already at or ahead more than AoB
			passQty = Math.min(extantQty, maxAoBQty);
		}
		
		//TODO: if calculated passiveQty is ahead more than the AoB, it could because of the missed cleanup, hence need to reduce it down
		
		double oppQty = vwap.getOpportunisticQty();
		
		// When not ahead more than maxAoB
		if (oppQty > 0 && -qtyToTarget < maxAoBQty) {
			aggQty = oppQty;
		} else {
			// when behind the maxAoBQty, calculate the normal aggressive quantity
			if (qtyToTarget > maxAoBQty) {
				aggQty += Math.random() * qtyToTarget + orderQty*vwap.getMinAggressiveOrderSize();
			}
		}
		
		if (aggQty > 0) {
			aggQty =  Math.min(Math.max(lotSize, aggQty), maxAoBQty);
		}
		
		qi.setPassiveQty(passQty);
		qi.setAggresiveQty(aggQty);					
	
		return qi;
	}

}
