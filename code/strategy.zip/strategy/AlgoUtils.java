package com.cyanspring.custom.strategy;

public class AlgoUtils {
	// Event name Constant
	public static final String EVENT_OPEN_AUCTION= "EVENT_OPEN_AUCTION";
}
