package com.cyanspring.custom.strategy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cyanspring.common.strategy.StrategyException;

public class TWAP extends VWAP {
	@SuppressWarnings("unused")
	private static final Logger log = LoggerFactory
			.getLogger(TWAP.class);
	
	public String getDescription() {
		return "This is TWAP strategy";
	}
	
	@Override 
	public void init() throws StrategyException {
		useLinearProfile = true;
		
		super.init();
	}
}
