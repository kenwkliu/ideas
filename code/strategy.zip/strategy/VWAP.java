package com.cyanspring.custom.strategy;

import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cyanspring.common.Clock;
import com.cyanspring.common.business.Execution;
import com.cyanspring.common.business.OrderField;
import com.cyanspring.common.event.AsyncEvent;
import com.cyanspring.common.event.AsyncTimerEvent;
import com.cyanspring.common.event.marketdata.QuoteEvent;
import com.cyanspring.common.event.marketdata.TradeEvent;
import com.cyanspring.common.event.order.AmendStrategyOrderEvent;
import com.cyanspring.common.event.order.UpdateChildOrderEvent;
import com.cyanspring.common.marketdata.Trade;
import com.cyanspring.common.marketsession.MarketSessionType;
import com.cyanspring.common.staticdata.IVolumeProfileManager;
import com.cyanspring.common.strategy.ExecuteTiming;
import com.cyanspring.common.strategy.StrategyException;
import com.cyanspring.common.type.OrderSide;
import com.cyanspring.common.type.StrategyState;
import com.cyanspring.common.util.OrderUtils;
import com.cyanspring.common.util.PriceUtils;
import com.cyanspring.common.util.TimeUtil;
import com.cyanspring.strategy.singleorder.SingleOrderStrategy;
import com.cyanspring.strategy.utils.QuoteUtil;

public class VWAP extends SingleOrderStrategy {
	//TODO: Read from config file
	protected double minPassiveOrderSize;
	protected double minAggressiveOrderSize;
	protected double maxAoB;
	protected int finishUpFromCloseInSec;

	protected AsyncTimerEvent contSessionRepeatTimerEvent = new AsyncTimerEvent();
	
	protected IVolumeProfileManager vpManager;
	protected boolean useLinearProfile = false;
	protected VolumeProfile vp;
	protected VolumeTracker vt;
	protected double volLimit = 0;
	protected double cleanUpPx = 0;
	protected double cleanUpVol = 0;

	protected double buySellRatio;
	protected double bsRatioScaleFactor;
	protected double maxBSRatio;
	protected double maxVWAPpi;	
	protected double bsRatioWeighting;
	protected double vwapPiWeighting;
	protected long opportunisticBuckets;
	protected long lastOpportunisticTime;
	protected double narrowSpreadWindow;
	
	
	@SuppressWarnings("unused")
	private static final Logger log = LoggerFactory
			.getLogger(VWAP.class);
	
	public String getDescription() {
		return "This is VWAP strategy";
	}

	@Override
	public void create(Object... objects) throws StrategyException {
		super.create(objects);
		vpManager = (IVolumeProfileManager)objects[3]; 
	}
	
	
	@Override 
	public void init() throws StrategyException {
		setTimerEventRequired(false);
		isExecuteAfterPostProcessUpdateChildOrderEvent = false;
				
		maxAoB = 0.02;
		minPassiveOrderSize = 0.005;
		minAggressiveOrderSize = 0.002;
		
		if (finishUpFromCloseInSec == 0) {
			finishUpFromCloseInSec = 30;
		}
		
		bsRatioScaleFactor = 60.0;
		maxBSRatio = 0.005;
		maxVWAPpi = 0.01;
		bsRatioWeighting = 1;
		vwapPiWeighting = 1;		
		opportunisticBuckets = 200;
		narrowSpreadWindow = maxAoB/2;

		// TODO: Params validation
		//volumeLimit, cleanUpPx, cleanUpVol > 0, 
		//if cleanUpVol>0 then cleanUpPx > 0 
		
		Integer interval = parentOrder.get(Integer.class, "interval");
		if (interval!=null && interval>0) {
			setTimerInterval(interval * 1000);
		} else {
			setTimerInterval(5000);
		}

		Double volLimitInput = parentOrder.get(Double.class, "volLimit");
		if (volLimitInput!=null && volLimitInput>0) {
			volLimit = volLimitInput / 100;
		}

		Double cleanUpPxInput = parentOrder.get(Double.class, "cleanUpPx");
		if (cleanUpPxInput!=null && cleanUpPxInput>0) {
			setCleanUpPx(cleanUpPxInput);
		}

		Double cleanUpVolInput = parentOrder.get(Double.class, "cleanUpVol");
		if (cleanUpVolInput!=null && cleanUpVolInput>0) {
			cleanUpVol = cleanUpVolInput;
		}		
		
		//TODO: move to more parent level
		if (parentOrder.getStartTime()==null) {
			parentOrder.setStartTime(Clock.getInstance().now());
		}
		
		if (parentOrder.getEndTime()==null) {
			Integer duration = parentOrder.get(Integer.class, "duration");
			
			if (duration==null || duration<=0) {
				duration = 15;
			}
			
			parentOrder.setEndTime(new Date(parentOrder.getStartTime().getTime() + duration*60*1000));
		}

		super.init();
		container.subscribe(TradeEvent.class, parentOrder.getSymbol(), this);
		container.scheduleRepeatTimerEvent(new Date(TimeUtil.getTodayTimeOnly() + marketRule.getSessionStartTime(MarketSessionType.AM_CONTINUOUS_TRADING)), getTimerInterval(), this, contSessionRepeatTimerEvent);
		
		// Init volume profile & tracker
		marketStatistic = new VolumeTracker(this);
		vt = (VolumeTracker)marketStatistic;
		
		long endTimeDuration = parentOrder.getEndTime().getTime() - parentOrder.getStartTime().getTime();
		
		if (useLinearProfile) {
			vp = new VolumeProfile(this, null, parentOrder.getStartTime().getTime(), parentOrder.getStartTime().getTime()+endTimeDuration, useLinearProfile);
		} else {
			vp = new VolumeProfile(this, vpManager.getVolumeProfileDataArray(parentOrder.getSymbol()), parentOrder.getStartTime().getTime(), parentOrder.getStartTime().getTime()+endTimeDuration, useLinearProfile);
			logInfo("===> logVolumeProfile:" + vp.getVolumeProfile());
		}
		
		logInfo("===> logTargetVolumeProfile:" + vp.getTargetVolumeProfile());
		
		// Open auction logic
		if (marketRule.isInOpenAuction(parentOrder.getStartTime().getTime()-TimeUtil.getTodayTimeOnly(), this)) {
			initOpenAuction();
		}
	}
	
	@Override
	public void uninit() {
		container.unsubscribe(TradeEvent.class, parentOrder.getSymbol(), this);
		super.uninit();
	}	
	
	protected void initOpenAuction() {
		long todayAuctionStartTime = TimeUtil.getTodayTimeOnly() + marketRule.getSessionStartTime(MarketSessionType.AM_AUCTION);
		long todayAuctionEndTime = TimeUtil.getTodayTimeOnly() + marketRule.getSessionEndTime(MarketSessionType.AM_AUCTION);
		container.scheduleTimerEvent(new Date(todayAuctionStartTime + 2000), this, new AlgoEvent(AlgoUtils.EVENT_OPEN_AUCTION));
		container.scheduleTimerEvent(new Date(todayAuctionStartTime + 5*60*1000), this, new AlgoEvent(AlgoUtils.EVENT_OPEN_AUCTION));
		container.scheduleTimerEvent(new Date(todayAuctionStartTime + 10*60*1000), this, new AlgoEvent(AlgoUtils.EVENT_OPEN_AUCTION));
		container.scheduleTimerEvent(new Date(todayAuctionEndTime - 3000), this, new AlgoEvent(AlgoUtils.EVENT_OPEN_AUCTION));
		
		// For Auction market order
		long todayAuctionMarketStartTime = TimeUtil.getTodayTimeOnly() + marketRule.getSessionStartTime(MarketSessionType.AM_AUCTION_MARKET_ONLY);
		long todayAuctionMarketEndTime = TimeUtil.getTodayTimeOnly() + marketRule.getSessionEndTime(MarketSessionType.AM_AUCTION_MARKET_ONLY);
		container.scheduleTimerEvent(new Date(todayAuctionMarketStartTime + 2000), this, new AlgoEvent(AlgoUtils.EVENT_OPEN_AUCTION));
		container.scheduleTimerEvent(new Date(todayAuctionMarketStartTime + 3*60*1000), this, new AlgoEvent(AlgoUtils.EVENT_OPEN_AUCTION));
		container.scheduleTimerEvent(new Date(todayAuctionMarketEndTime - 3000), this, new AlgoEvent(AlgoUtils.EVENT_OPEN_AUCTION));
		
	}
	
	@Override
	public void onEvent(AsyncEvent event) {
		if (event instanceof AlgoEvent) {
			processAlgoEvent((AlgoEvent)event);
		} else {
			super.onEvent(event);
		}
	}
	
	protected void processAlgoEvent(AlgoEvent event) {
		if (AlgoUtils.EVENT_OPEN_AUCTION.equals(event.getKey())) {
			execute(ExecuteTiming.NOW);
		}
	}
	
	@Override
	protected void processAmendStrategyOrderEvent(AmendStrategyOrderEvent event) {
		//TODO: Validate amendment and reject invalid cases

		Map<String, Object> changFields = event.getFields();
		if (changFields != null && changFields.size() > 0) {
			//If it's quantity amendment and order has executions, refresh volume profile
			if (parentOrder.getCumQty()>0) {
				double newQty = Double.parseDouble(changFields.get(OrderField.QUANTITY.value()).toString());
				double refreshRate = vp.getCurrentTargetRate() * parentOrder.getQuantity() / newQty;
				
				vp.refreshProfile(Clock.getInstance().now().getTime(), parentOrder.getEndTime().getTime(), refreshRate);
				logInfo("===> Qty amendment and refresh profile target" + vp.getTargetVolumeProfile());
				
			}
		}

		super.processAmendStrategyOrderEvent(event);
	}
	
	@Override
	protected void processQuoteEvent(QuoteEvent event) {
		quote = event.getQuote();
		
		if (cleanUpPx>0 && isCleanUpNow()) {
			execute(ExecuteTiming.NOW);
		} 
	}

	@Override
	protected void processTradeEvent(TradeEvent event) {
		super.processTradeEvent(event);
		
		if (cleanUpPx>0 && cleanUpVol>0) {
			Trade trade = event.getTrade();
			if(getState().equals(StrategyState.Running) && OrderUtils.inLimit(trade.getPrice(), cleanUpPx, parentOrder.getSide())) {
				vt.cleanUpTradeUpdate(trade);
			}
		}
	}
	
	@Override
	protected void preProcessUpdateChildOrderEvent(UpdateChildOrderEvent event) {
		super.preProcessUpdateChildOrderEvent(event);
		
		if (cleanUpVol>0 && cleanUpPx>0 && event.getExecution() != null) {
			Execution execution = event.getExecution(); 
			if(getState().equals(StrategyState.Running) && OrderUtils.inLimit(execution.getPrice(), cleanUpPx, parentOrder.getSide())) {
				vt.cleanUpExecutionUpdate(execution);
			}
		}
	}
	
	@Override
	protected void processAsyncTimerEvent(AsyncTimerEvent event) {
		executionManager.onMaintenance();
		execute(ExecuteTiming.ASAP);
	}
	
	@Override
	public void execute(ExecuteTiming timing) {
		if (marketRule.isMarketOpenForTradingNow(this)) {
			//do not execute if both bid/ask are not there
			if (QuoteUtil.hasBidAsk(quote)) {
				super.execute(timing);
			} else {
				logInfo("!!! No bid or ask to execute");			
			}
		}
	}
	
	public double getMinPassiveOrderSize() {
		return minPassiveOrderSize;
	}
	
	public double getMinAggressiveOrderSize() {
		return minAggressiveOrderSize;
	}	
	
	public double getMaxAoB() {
		return maxAoB;
	}
	
	public double getBuySellRatio() {
		OrderSide side = parentOrder.getSide();
		buySellRatio = Math.log10(quote.getBidVol()/quote.getAskVol());
		double ratio = side.isBuy() ? buySellRatio : -buySellRatio;
		
		return Math.min(ratio/bsRatioScaleFactor, maxBSRatio);
	}

	public double getRawBuySellRatio() {
		return Math.log10(quote.getBidVol()/quote.getAskVol());
	}	

	public double getDepthBuySellRatio() {
		return Math.log10(
				(3*quote.getBidVol() + quote.getBid1Vol() + 0.5*quote.getBid2Vol())
				/(3*quote.getAskVol() + quote.getAsk1Vol() + 0.5*quote.getAsk2Vol()));
	}		
	
	public double getOrderVWAP() {
		return marketStatistic.getOtVWAP();
	}
	
	public double getVWAPpi() {
		//TODO: ignore the certain trading period
		
		OrderSide side = parentOrder.getSide();
		double orderVWAP = getOrderVWAP();
		double pi = 0;
		
		if (PriceUtils.Equal(orderVWAP, 0)) {
			return 0;
		}
		
		pi = side.isBuy() ? (orderVWAP-quote.getAsk())/orderVWAP : (quote.getBid()-orderVWAP)/orderVWAP;  

		return Math.min(pi, maxVWAPpi);
	}
	
	public double getVWAPPerf(OrderSide side) {
		double avgPx = parentOrder.getAvgPx();
		double oVWAP = getOrderVWAP();
		
		if (PriceUtils.isZero(avgPx) || PriceUtils.isZero(oVWAP)) {
			return 0;
		}
		
		if (side.isBuy()) {
			return (oVWAP - avgPx)/oVWAP;
		} else {
			return (avgPx - oVWAP)/oVWAP;
		}
	}
	
	public double getCurrentAoB() {
		return -getQtyToTarget() / parentOrder.getQuantity();
	}
	
	public double getQtyToTarget() {
		return getTargetQty() - parentOrder.getCumQty();
	}
	
	public double getProfileRate() {
		return vp.getCurrentTargetRate();
	}
	
	public double getTargetRate() {
		return getTargetQty() / parentOrder.getQuantity();
	}
	
	public double getTargetQty() {
		double tgtQty = parentOrder.getQuantity() * getProfileRate();
		
		if (volLimit>0) {
			double limitQty = marketRule.isInOpenAuctionNow(this) ? 
					vt.getTargetQty(volLimit) : vt.getOtMarketVol() * volLimit; 

			return Math.min(limitQty, tgtQty);
		}
		
		return tgtQty;
	}
	
	public double getOpportunisticQty() {
		double oppQty = parentOrder.getQuantity() *
				(bsRatioWeighting * getBuySellRatio() + vwapPiWeighting * getVWAPpi());

		if (oppQty > getRefData().getLotSize()) {
			long oppQtyInterval = (parentOrder.getEndTime().getTime() - parentOrder.getStartTime().getTime()) / opportunisticBuckets;
			
			if (Clock.getInstance().now().getTime() - lastOpportunisticTime > oppQtyInterval) {
				lastOpportunisticTime = Clock.getInstance().now().getTime();
				logInfo("===> Positive OpportunisticQty:" + oppQty);
				
				return oppQty;
			}
			
		} 
		
		//TODO: Work on negative qty case to slower than the aggQty;
		return 0;
	}
	
	public double getFinishUpQty() {
		if (volLimit>0) {
			return Math.min(parentOrder.getRemainingQty(), vt.getTargetQty(volLimit));
		} else {
			return parentOrder.getRemainingQty();
		}
	}
	
	public boolean isNarrowSpreadNow() {
		//TODO: off limit no need to narrow spread
		//TODO: Add decay factor
		
		// If CurrentAoB is behind more than narrowSpreadWindow
		if (-getCurrentAoB() > narrowSpreadWindow) {
			return true;
		} else {
			return false;
		}
	}
	
	public double getRunningPov() {
		return vt.getRunningPov();
	}
	
	public double getCleanUpPx() {
		return cleanUpPx;
	}
	
	public void setCleanUpPx(double px) {
		cleanUpPx = px;
	}
	
	public double getCleanUpVol() {
		return cleanUpVol;
	}
	
	public double getRunningCleanUpPov() {
		return vt.getRunningCleanUpPov();
	}
	
	public boolean isCleanUpNow() {
		boolean isCleanUpNow = isInCleanUpPx();
		
		if (isCleanUpNow && cleanUpVol > 0) {
			if (getCleanUpQty() <= 0) {
				isCleanUpNow = false;
			}
		}
		
		return isCleanUpNow;
	}	
	
	
	public boolean isInCleanUpPx() {
		if (cleanUpPx <= 0 || !QuoteUtil.hasBidAsk(quote)) return false;
		
		if (parentOrder.getSide().isBuy()) {
			return PriceUtils.EqualGreaterThan(cleanUpPx, quote.getAsk());
		} else {
			return PriceUtils.EqualLessThan(cleanUpPx, quote.getBid());
		}		
	}

	public double getCleanUpQty() {
		double qty = QuoteUtil.getOppositeQuantityToPrice(quote, cleanUpPx, parentOrder.getSide()); 
		
		if (cleanUpVol > 0) {
			qty = Math.min(qty, vt.getCleanUpQty(cleanUpVol/100));
		}
		
		return qty;		
	}
	
	public boolean isFinishUp() {
		if (TimeUtil.getNowInTodayTimeOnly() > getFinishUpTime()) {
			return true;
		} else {
			return false;
		}
	}

	public long getFinishUpTime() {
		return parentOrder.getEndTime().getTime() - TimeUtil.getTodayTimeOnly() - finishUpFromCloseInSec*1000;
	}
}
