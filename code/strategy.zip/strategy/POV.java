/*******************************************************************************
 * Copyright (c) 2011-2012 Cyan Spring Limited
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms specified by license file attached.
 * 
 * Software distributed under the License is released on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 ******************************************************************************/
package com.cyanspring.custom.strategy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cyanspring.common.business.OrderField;
import com.cyanspring.common.event.marketdata.TradeEvent;
import com.cyanspring.common.strategy.StrategyException;
import com.cyanspring.strategy.singleorder.SingleOrderStrategy;

public class POV extends SingleOrderStrategy{
	@SuppressWarnings("unused")
	private static final Logger log = LoggerFactory
			.getLogger(POV.class);
	
	protected double pov;
	protected VolumeTracker vt;
	
	@Override
	public void init() throws StrategyException {
		pov = parentOrder.get(Double.TYPE, OrderField.POV.value()) / 100;
		
		super.init();
		container.subscribe(TradeEvent.class, parentOrder.getSymbol(), this);
		
		marketStatistic = new VolumeTracker(this);
		vt = (VolumeTracker)marketStatistic;
	}
	
	@Override
	public void uninit() {
		container.unsubscribe(TradeEvent.class, parentOrder.getSymbol(), this);
		super.uninit();
	}
	
	protected double getTargetQty() {
		return vt.getTargetQty(pov);
	}
	
	protected double getRunningPov() {
		return vt.getRunningPov();
	}
}
