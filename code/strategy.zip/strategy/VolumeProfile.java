package com.cyanspring.custom.strategy;

import java.text.SimpleDateFormat;

import com.cyanspring.common.Clock;
import com.cyanspring.common.marketsession.MarketSessionType;
import com.cyanspring.common.staticdata.VolumeProfileManager.VolumeProfileDataArray;
import com.cyanspring.common.strategy.IStrategy;
import com.cyanspring.common.util.FormatUtils;
import com.cyanspring.common.util.TimeUtil;
import com.cyanspring.common.validation.IMarketRule;

public class VolumeProfile {
	private final SimpleDateFormat df = new SimpleDateFormat("HH:mm");
	private final long bucketInterval = 300000;
	private long TODAY_TIME = TimeUtil.getTodayTimeOnly();
	
	private IStrategy strategy;
	private IMarketRule marketRule;
	private long[] time;
	private double[] percent;
	
	private long startTime;
	private long endTime;
	private double refreshRate;
	private boolean useLinearProfile = false;

	private long openAuctionStartTime;
	private long marketStartTime;
	private long lunchStartTime;
	private long lunchEndTime;	
	private long marketCloseTime;
	
	public VolumeProfile(IStrategy strategy, VolumeProfileDataArray data, long startTime, long endTime, boolean useLinearProfile) {
		this.strategy = strategy;
		this.marketRule = strategy.getMarketRule();
		
		// init the session timing
		openAuctionStartTime = marketRule.getSessionStartTime(MarketSessionType.AM_AUCTION);
		marketStartTime = marketRule.getSessionStartTime(MarketSessionType.AM_CONTINUOUS_TRADING);
		lunchStartTime = marketRule.getSessionStartTime(MarketSessionType.LUNCH_BLOCKING);
		lunchEndTime = marketRule.getSessionEndTime(MarketSessionType.LUNCH_BLOCKING);
		marketCloseTime = marketRule.getSessionEndTime(MarketSessionType.PM_CONTINUOUS_TRADING);
		
		if (data != null) {
			time = data.getTime();
			percent = data.getPercentage();
		}
		
		refreshRate=0;
		this.startTime = getAdjustedStartTime(startTime);
		this.endTime = getAdjustedEndTime(endTime);
		this.useLinearProfile = useLinearProfile;
	}
	
	private long getAdjustedStartTime(long time) {
		long now = Clock.getInstance().now().getTime();
		
		if (time < now) {
			time = now;
		}
		
		return time - TODAY_TIME;
	}
	
	private long getAdjustedEndTime(long time) {
		time -= TODAY_TIME;
		
		return Math.min(time, marketCloseTime);
	}
	
	public String getVolumeProfile() {
		StringBuilder sb = new StringBuilder("\n");
		
		for (int i=0; i<time.length; i++) {
			sb.append(df.format(TimeUtil.parseMilliSecondSinceMidNight(time[i])) + " -> " + FormatUtils.twoDP(percent[i]*100) + "% \n");
		}
		
		return sb.toString();
	}
	
	public String getTargetVolumeProfile() {
		StringBuilder sb = new StringBuilder("\n");
		
		for (long i=startTime; i<endTime; i+=bucketInterval) {
			sb.append(df.format(TimeUtil.parseMilliSecondSinceMidNight(i)) + " -> " + FormatUtils.twoDP(getTargetRate(i,startTime,endTime)*100) + "% \n");
		}
		
		sb.append(df.format(TimeUtil.parseMilliSecondSinceMidNight(endTime)) + " -> " + FormatUtils.twoDP(getTargetRate(endTime,startTime,endTime)*100) + "% \n");
		
		return sb.toString();
	}
	
	public void refreshProfile(long startTime, long endTime, double refreshRate) {
		this.startTime = getAdjustedStartTime(startTime);
		this.endTime = getAdjustedEndTime(endTime);
		this.refreshRate = refreshRate;
	}
	
	public double getCurrentTargetRate() {
		long now = Clock.getInstance().now().getTime() - TODAY_TIME;
	
		return getTargetRate(now);
	}
	
	public double getTargetRate(long targetTime) {
		return getTargetRate(targetTime, startTime, endTime);
	}
	
	private double getTargetRate(long targetTime, long startTime, long endTime) {
		if (startTime>=endTime) return 0;
		//if (targetTime<=startTime) return 0;
		if (targetTime>=endTime) return 1;

		// Before Open Auction start
		if (targetTime < openAuctionStartTime) return 0;
		
		// Treat Open Auction as one bucket (5mins of volume)
		if (startTime<marketStartTime && marketRule.isInOpenAuction(startTime, strategy)) {
			startTime = marketStartTime - bucketInterval;
		// Fall into blocking period before market open
		} else if (startTime < marketStartTime) {
			startTime = marketStartTime;
		}	
		
		if (endTime > marketCloseTime) endTime = marketCloseTime;		
		
		// Before Market Start and inside the open auction
		if (targetTime < marketStartTime) {
			targetTime = marketStartTime;
		}
		
		double rate = 0;
		
		if (useLinearProfile) {
			long totalDuration = durationExcludeLunch(startTime,endTime);
			if (totalDuration == 0) return 0;
		
			rate = (double)durationExcludeLunch(startTime, targetTime)/totalDuration;
		} else {
			rate = ((getProfilePercent(targetTime) - getProfilePercent(startTime)) 
				/ (getProfilePercent(endTime) - getProfilePercent(startTime)));
		}
		
		return rate * (1-refreshRate) + refreshRate;
	}

	private long durationExcludeLunch(long startTime, long endTime) {
		// Start and End both within lunch, return 0;
		long lunchDuration = 0;

		if (startTime>=lunchStartTime && startTime<=lunchEndTime && endTime>=lunchStartTime && endTime<=lunchEndTime) return 0;
		
		// Start after lunch or end before lunch: no need to exclude lunch duration
		if (startTime>=lunchEndTime || endTime<=lunchStartTime) {
			lunchDuration = 0;
		
		// Start inside lunch
		} else if (startTime>=lunchStartTime && startTime<lunchEndTime) {
			lunchDuration = lunchEndTime - startTime;
		
		// End inside lunch
		} else if (endTime>lunchStartTime && endTime<=lunchEndTime) {
			lunchDuration = endTime - lunchStartTime;

		// otherwise exclude the full lunch period
		} else {
			lunchDuration = (lunchEndTime-lunchStartTime);
		}

		return endTime-startTime - lunchDuration;
	}	
	
	private double getProfilePercent(long now) {
		int lowIndex=0, highIndex=0;
		
		// get where's the now 
		if (now<=time[0]) {
			lowIndex = 0;
			highIndex = 0;
		} else if (now>=time[time.length-1]) {
			lowIndex = time.length-1;
			highIndex = time.length-1;
		} else {
			for (int i=0; i<time.length-1; i++) {
				if (now == time[i]) {
					lowIndex = i;
					highIndex = i;
					break;
				} else if (now>time[i] && now<time[i+1]) {
					lowIndex = i;
					highIndex = i+1;
					break;
				}
			}
		}
		
		if (lowIndex == highIndex) {
			return percent[lowIndex];
		} else {
			return (percent[highIndex] - percent[lowIndex]) * ((double)((time[lowIndex] - now)*-1)/(time[highIndex] - time[lowIndex])) + percent[lowIndex];
		}
	}
	
}
