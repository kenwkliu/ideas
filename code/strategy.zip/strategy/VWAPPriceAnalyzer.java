package com.cyanspring.custom.strategy;

import com.cyanspring.common.business.ParentOrder;
import com.cyanspring.common.marketdata.Quote;
import com.cyanspring.common.staticdata.ITickTable;
import com.cyanspring.common.strategy.PriceAllocation;
import com.cyanspring.common.strategy.PriceInstruction;
import com.cyanspring.common.type.ExchangeOrderType;
import com.cyanspring.common.util.FormatUtils;
import com.cyanspring.common.util.PriceUtils;
import com.cyanspring.strategy.singleorder.AbstractPriceAnalyzer;
import com.cyanspring.strategy.singleorder.QuantityInstruction;
import com.cyanspring.strategy.singleorder.SingleOrderStrategy;

public class VWAPPriceAnalyzer extends AbstractPriceAnalyzer {
	private double currentPassivePx = 0;
	
	@Override
	protected PriceInstruction calculate(QuantityInstruction qtyInstruction,
			SingleOrderStrategy strategy) {

		AlgoQtyInstruction qi = (AlgoQtyInstruction)qtyInstruction;
		VWAP vwap = (VWAP)strategy;
		ParentOrder order = strategy.getParentOrder();
		Quote quote = strategy.getQuote();
		PriceInstruction pi = new PriceInstruction();
		
		ITickTable tickTable = strategy.getTickTable();
		double price=0, nextTick=0;

		StringBuilder sb = new StringBuilder("===> Algo finialized px/qty: ");
		
		if (qi.getAuctionQty() > 0) {
			ExchangeOrderType orderType = ExchangeOrderType.LIMIT;			
			
			if (PriceUtils.isZero(order.getPrice())) {
				price = 0;
				orderType = ExchangeOrderType.MARKET;
			} else {
				price = order.getPrice();
			}
			
			pi.add(new PriceAllocation(order.getSymbol(), order.getSide(), price, qi.getAuctionQty(), 
					orderType, strategy.getId()));
				
			sb.append("AuctionOrder: " + price + "@" + qi.getAuctionQty());			
		}
		
		
		// setting the price to best bid for buy or best ask for sell
		// narrow spread if necessary
		if (qi.getPassiveQty() > 0) {

			price = order.getSide().isBuy() ? quote.getBid() : quote.getAsk();
			
			if (vwap.isNarrowSpreadNow()) {
				nextTick = order.getSide().isBuy() ? tickTable.tickUp(price, false) : tickTable.tickDown(price, false);;
				
				if ((order.getSide().isBuy() && !PriceUtils.EqualGreaterThan(nextTick, quote.getAsk()))
						|| (order.getSide().isSell() && !PriceUtils.EqualLessThan(nextTick, quote.getBid()))) {
						
					price = nextTick;
					strategy.logInfo("===> Narrow spread by one tick: bid, ask, new price, AoB%: " 
							+ quote.getBid() + ", " + quote.getAsk() + ", " + price + ", " + FormatUtils.twoDP(vwap.getCurrentAoB()*100) + "%");
				} 
			}
			

			price = getCompliantPrice(strategy, price);
			price = getSafePassivePrice(currentPassivePx, price, order.getSide(), strategy.getChildOrders());
			currentPassivePx = price;

			pi.add(new PriceAllocation(order.getSymbol(), order.getSide(), price, qi.getPassiveQty(), 
				ExchangeOrderType.LIMIT, strategy.getId()));
			
			sb.append("PassiveOrder: " + price + "@" + qi.getPassiveQty());
		}
		
		if (qi.getAggresiveQty() > 0) {
			price = order.getSide().isBuy() ? quote.getAsk() : quote.getBid();
			double qty = qi.getAggresiveQty();
			double touchQty = order.getSide().isBuy() ? quote.getAskVol() : quote
					.getBidVol();
			
			// since we don't want to move market much, we only take out one
			// price level of far touch
			if (qty > touchQty) {
				qty = touchQty;
				
				strategy.logInfo("===> Capping the aggQty to far touch size: " + qty);
			}
			
			pi.add(new PriceAllocation(order.getSymbol(), order.getSide(), price, qty, 
					ExchangeOrderType.LIMIT, strategy.getId()));
			
			sb.append(", AggressiveOrder: " + price + "@" + qty);
		}

		if (qi.getCleanUpQty() > 0) {
			pi.add(new PriceAllocation(order.getSymbol(), order.getSide(), vwap.getCleanUpPx(), qi.getCleanUpQty(), 
					ExchangeOrderType.LIMIT, strategy.getId()));
			
			sb.append(", CleanUpOrder: " + vwap.getCleanUpPx() + "@" + qi.getCleanUpQty());
		}
		
		if (qi.getFinishUpQty() > 0) {
			//TODO read from config
			int finishUpAggTicks = 4;
			
			if (order.getSide().isBuy()) {
				price = quote.getAsk(); 
				
				for (int i=0; i<finishUpAggTicks; i++) {
					price = tickTable.tickUp(price, false);
				}
				
			} else {
				price = quote.getBid();
				
				for (int i=0; i<finishUpAggTicks; i++) {
					price = tickTable.tickDown(price, false);
				}
			}
			
			pi.add(new PriceAllocation(order.getSymbol(), order.getSide(), price, qi.getFinishUpQty(), 
					ExchangeOrderType.LIMIT, strategy.getId()));
			
			sb.append(", FinishUpOrder: " + price + "@" + qi.getFinishUpQty());
		}
		
		strategy.logInfo(sb.toString());
		return pi;
	}

}
