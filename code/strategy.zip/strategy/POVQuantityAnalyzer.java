/*******************************************************************************
 * Copyright (c) 2011-2012 Cyan Spring Limited
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms specified by license file attached.
 * 
 * Software distributed under the License is released on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 ******************************************************************************/
package com.cyanspring.custom.strategy;

import com.cyanspring.common.business.ParentOrder;
import com.cyanspring.common.marketdata.Quote;
import com.cyanspring.common.util.FormatUtils;
import com.cyanspring.common.util.PriceUtils;
import com.cyanspring.strategy.singleorder.AbstractQuantityAnalyzer;
import com.cyanspring.strategy.singleorder.QuantityInstruction;
import com.cyanspring.strategy.singleorder.SingleOrderStrategy;
import com.cyanspring.strategy.utils.QuoteUtil;

public class POVQuantityAnalyzer extends AbstractQuantityAnalyzer {

	@Override
	public QuantityInstruction calculate(SingleOrderStrategy strategy) {
		POV povs = (POV)strategy;
		double pov = povs.pov;
		
		ParentOrder parentOrder = strategy.getParentOrder();
		Quote quote = strategy.getAdjQuote();
		
		strategy.logInfo("MktStat: " + strategy.getMarketStatistic());
		strategy.logInfo("Running POV: " + FormatUtils.twoDP(povs.getRunningPov()));

		QuantityInstruction qi = new QuantityInstruction();
		
		double aggressiveQty = povs.getTargetQty();

		//TODO: if it's OTM limit order, should use the OTM limit price size
		double base = 0;
		
		if (parentOrder.getPrice() > 0) {
			base = QuoteUtil.getQuantityAtPrice(quote, parentOrder.getPrice(), parentOrder.getSide());
		} else {
			base = parentOrder.getSide().isBuy()? quote.getBidVol():quote.getAskVol();
		}
		
		strategy.logInfo("===> baseQty: " + FormatUtils.zeroDP(base));
		double passiveQty = pov * base /(1-pov);
		
		//if we over executed our pov
		if(PriceUtils.LessThan(aggressiveQty, 0)) {
			passiveQty += aggressiveQty;
			aggressiveQty = 0;
		}
		
		qi.setAggresiveQty(aggressiveQty);
		qi.setPassiveQty(passiveQty);
		return qi;
	}
}
