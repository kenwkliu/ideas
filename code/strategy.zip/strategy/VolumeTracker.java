package com.cyanspring.custom.strategy;

import com.cyanspring.common.business.Execution;
import com.cyanspring.common.marketdata.Trade;
import com.cyanspring.strategy.MarketStatistic;
import com.cyanspring.strategy.singleorder.SingleOrderStrategy;

public class VolumeTracker extends MarketStatistic {
	private SingleOrderStrategy orderStrategy;
	private double cleanUpMarketVol = 0;		
	private double cleanUpMyVol = 0;
	
	public VolumeTracker(SingleOrderStrategy orderStrategy) {
		this.orderStrategy = orderStrategy;
	}
	
	public double getTargetQty(double pov) {
		if (orderStrategy.getMarketRule().isInOpenAuctionNow(orderStrategy)) {
			return (pov * orderStrategy.getQuote().getIev()) / (1 - pov);
		} else {
			return (pov * getOtMarketVol() - getOtMyVol()) / (1 - pov);
		}
	}	
	
	public double getRunningPov() {
		if (getOtMarketVol() > 0) {
			return getOtMyVol() * 100 / getOtMarketVol();
		} else {
			return 0;
		}
	}	

	public double getCleanUpMarketVol() {
		return cleanUpMarketVol;
	}
	
	public double getCleanUpMyVol() {
		return cleanUpMyVol;
	}
	
	public double getRunningCleanUpPov() {
		if (getCleanUpMarketVol() > 0) {
			return getCleanUpMyVol() * 100 / getCleanUpMarketVol();
		} else {
			return 0;
		}
	}	
	
	public void cleanUpTradeUpdate(Trade trade) {
		cleanUpMarketVol += trade.getQuantity();		
	}
	
	public void cleanUpExecutionUpdate(Execution execution) {
		cleanUpMyVol += execution.getQuantity();
	}
	
	protected double getCleanUpQty(double pov) {
		return (pov * cleanUpMarketVol - cleanUpMyVol) / (1 - pov);
	}
	
	@Override
	public void reset() {
		super.reset();
		cleanUpMarketVol = 0;
		cleanUpMyVol = 0;
	}	
}
