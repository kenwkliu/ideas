package com.cyanspring.custom.strategy;

import com.cyanspring.strategy.singleorder.QuantityInstruction;

public class AlgoQtyInstruction extends QuantityInstruction {
	protected double auctionQty;
	protected double cleanUpQty;
	protected double finishUpQty;
	
	public double getAuctionQty() {
		return auctionQty;
	}
	public void setAuctionQty(double auctionQty) {
		this.auctionQty = auctionQty;
	}	

	public double getCleanUpQty() {
		return cleanUpQty;
	}
	public void setCleanUpQty(double cleanUpQty) {
		this.cleanUpQty = cleanUpQty;
	}	
	
	public double getFinishUpQty() {
		return finishUpQty;
	}
	public void setFinishUpQty(double finishUpQty) {
		this.finishUpQty = finishUpQty;
	}	
	
	public double getTotalQty() {
		return auctionQty + cleanUpQty + finishUpQty + aggresiveQty + passiveQty;
	}
}
